# HW3

1- Date class’ına 4 adet extension yazılacak
- .day parametresiyle gün bilgisini döndüren
- .month parametresiyle ay bilgisini döndüren
- .year parametresiyle yıl bilgisini döndüren
- .dateAsPrettyString parametresiyle tarihi “28<>12<>2021” formatında string olarak döndüren
extensionlar yazılması beklenmektedir.

2- WeeklyDemos reposuna fork işlemi yapılarak Calculator projesi kopyalanacak; mevcut projeye 4 işlem (+, -, /, *) ve C, CE, = işlemleri eklenecektir.

Ödevin son tarihi önümüzdeki ders başlayana kadar.
Ödevle ilgili anlaşılmayan yerleri gruptan sorarsak aynı soruların sorulmasını engellenmiş oluruz :)
Bir sorun yaşadığınızda biz asistanlara yazmaya çekinmeyin :)
