//
//  ViewController.swift
//  Week1
//
//  Created by Semih Emre ÜNLÜ on 11.12.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var countButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func countButtonTapped(_ sender: UIButton) {
    }

}

